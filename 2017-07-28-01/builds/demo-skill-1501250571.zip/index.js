var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback){
  var alexa = Alexa.handler(event, context);
  alexa.registerHandlers(handlers);
  alexa.execute();
};

var handlers = {

  'NewSession': function () {
    this.emit(':ask', 'Hello and welcome! Please introduce yourself by saying: My name is, and then your name.', 'You can introduce yourself by saying: My name is, and then your name.');
  },

  'LaunchRequest': function () {
    this.emit(':ask', 'Welcome! You introduce yourself by saying: My name is, and then your name.', 'Please introduce yourself by saying: My name is, and then your name.');
  },

  'NameCapture': function () {
    // Get Slot Values
    var nameSlot = this.event.request.intent.slots.name.value;

    // Get Name
    var name;
    if (nameSlot) {
      name = USFirstNameSlot;
    }

    // Save Name in Session Attributes and Ask for Country
    if (name) {
      this.attributes['userName'] = name;
      this.emit(':tell', `Nice to meet you ${name}! I'll greet you by name the next time we talk`);
    } else {
      this.emit(':ask', `Sorry, I didn\'t recognise that name!`, `'Tell me your name by saying: My name is, and then your name.'`);
    }
  }

};
