var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback){
  var alexa = Alexa.handler(event, context);
  alexa.registerHandlers(handlers);
  alexa.execute();
};

var handlers = {

  'LaunchRequest': function () {
    this.emit(':ask', 'Can you say hello?', 'Say hello to test the Hello Intent.');
  },
  'HelloIntent': function() {
    var userName = this.event.request.intent.slots.name.value;

    if (userName !== undefined) {
      this.emit(':tell', `Nice to meet you ${userName}`);
    } else {
      this.emit(':tell', 'Hello! Nice to meet you.');
    }

  },
  'Unhandled': function (){
    this.emit(':tell', 'Sorry, I dont understand.');
  }
};
